<?php
  $ninjas = ['shaun' , 'ruy','yoshi'];
  echo $ninjas[1] . '<br />';

  echo "<br>";

  $haturi = ['shichan' ,'shinzo'];
  echo $haturi[1] . '<br />';

?> 

