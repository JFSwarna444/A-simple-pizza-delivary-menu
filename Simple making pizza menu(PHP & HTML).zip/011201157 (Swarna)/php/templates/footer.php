<footer class='section'>
	<div class='center red-text'>Copyright 2019 Ninja Pizzas</div>
</footer>
 </body>