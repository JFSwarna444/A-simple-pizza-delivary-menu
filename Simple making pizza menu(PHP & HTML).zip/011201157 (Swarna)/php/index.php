 <?php

	///vaiable & constants///

 // // $name1 = "yoy <br>";
 //  $name2 = "ninja hatori <br>";
 //  $age = 30 ;
 // // echo $name1;
 //  echo $name2;
 //  echo $age;
 //  echo "<br>";

 //  $name1 ='Shinzo';   //overwritten name1
 //  echo $name1;
 //  define('name','YoshioNaga');
 //  echo '<br>';

 // // define('name1','ma');
 //  ///


 //  ///strings///

 //  $stringone = 'my email is ';
 //  $stringtwo = 'jswarna201157@bscse.uiu.ac.bd';

 //  echo $stringone . $stringtwo;  // concatenates

 //  echo "<br>";


 //  $name = "messi";
 //  echo 'hey!!, my name is ' . $name;
 //  echo '<br>';

 //  echo 'my name is $name';

 //  echo '<br>';

 //  echo "the ninja screamed \"whaaaaa\"";

 //  echo "<br>";
 //  echo 'the ninjas screamed "whaaaaa is"';

 //  echo "<br>";



 //  //finding character
 //  echo $name[0]; 
 //  echo "<br>";
 //  echo $name2[2];
 //  echo "<br>";


 //  //length of string
 //  echo strlen($name);

 //  echo "<br>";
 //  echo strlen($name2);
 //  echo "<br>";


 //  //string uppercase
 //  echo strtoupper($name);
 //  echo "<br>";
 //  echo strtoupper($name2);


 //  //string lowercase

 //  echo strtolower($name2);
  
 //  echo strtolower($stringone);
 //  echo '<br>';

 //  //string replace
 //  echo str_replace('m', 'w', $name);
 //  echo "<br>";
 //  echo str_replace('S', 'R', $name1);




 //  ///Numbers///

 //  //basic operators = +, -, *, /, **
 //  echo "<br>";
 //  $radius = 25;
 //  $pi = 3.14;

 //  echo $pi * $radius**2;
	// echo "<br>";

	// //order of operation (B I D M A S)
	// echo 2* (4+9) /3;
	// echo '<br>';
	// echo 4/(67.8 * 6) ** 4;
	// echo '<br>';


	// //increment & decrement operation

	// // echo $radius++;     //25
	// // echo "<br>";
	// // echo $radius;       //26
	// // echo "<br>";
	// // echo ++$radius;     //27
	// // echo "<br>";


	// echo $radius--;
	// echo "<br>";
	// echo $radius;

	// echo "<br>";


	// //shorthand operators

	//  $age =20;
	//  echo $age;        //20
	//  echo "<br>";
	//  $age += 10; 
	//  echo $age;      //20 + 10 = 30
	//  echo "<br>";

	//   $age = 20;
 //      $age -= 10;      
 //      echo $age;     //20 - 10 = 10
 //      echo "<br>";

 //      echo $age = 49;
 //      echo "<br>";
 //      echo $age += 26;
 //      echo "<br>";

 //      $age = 49;
 //      $age -= 26;
 //      echo $age1 = $age;       //49 - 26 = 23
 //      echo "<br>";


 //      echo $age = 25;
 //      echo "<br>";
 //      echo $age *= 3;
 //      echo "<br>";


 //      echo $age = 25;
 //      echo "<br>";
 //      echo $age /=2;
 //      echo "<br>";


 //      echo $age = 25;
 //      echo "<br>";
 //      echo $age %=2;
 //      echo "<br>";


 //      //number functions

 //      echo floor($pi);
 //      echo "<br>";
 //      echo ceil($pi);
 //      echo "<br>";
 //      echo pi();
 //      echo "<br>";



 //      ///Arrays///

 //      //indexed arrays

 //      $peopleone = ['shaun','crystal','raun'];
 //      echo $peopleone[1];
 //      echo "<br>";

	  
 //      //altranative way to create a array function
 //      $peopletwo = array('ken','chen-li');
 //      echo $peopletwo[1];
 //      echo "<br>";


 //      $ages = [20, 30, 40, 50];
 //      print_r($ages);
 //      echo "<br>";

 //      $ages[1] = 25;    //update age index 1
 //      print_r($ages);
 //      echo "<br>";



 //      //add extra value
 //      $ages[] =60;
 //      print_r($ages);
 //      echo "<br>";


 //      //another way to add extra value

 //      array_push($ages, 70);
 //      print_r($ages);
 //      echo "<br>";

 //      echo count($ages);    //count array
 //      echo "<br>";



 //      //merge arrays
 //      $peoplethree = array_merge($peopleone, $peopletwo);
 //      print_r($peoplethree);
 //      echo "<br>";



 //      //associative arrays(key & values pairs)
	  
 //      /*echo 'warrior1';
 //      */
 //      $ninjaone =['shaun' => 'black','mario' =>'orange','luigi'=>'brown'];
 //      echo $ninjaone['mario'];
 //      echo "<br>";
 //      print_r($ninjaone);

 //      echo "<br>";

 //      $ninjatwo = array('kai'=> 'green', 'browser'=>'yellow');
 //      print_r ($ninjatwo);
 //      echo "<br>";
	  

 //      $ninjatwo ['browser'] ='pink';
 //      print_r($ninjatwo);


 //      echo "<br>";




 //      echo count($ninjaone);
 //      echo "<br>";

 //      $ninja3 = array_merge($ninjaone , $ninjatwo);
 //      print_r($ninja3);

 //      echo "<br>";





 //      ///multi-dimensional arrays///

 //      $blogs =[
 //      	['mario party' ,'mario',  'loren',   30],
 //      	['mario kart cheats' ,'toad', 'lorem',  25],
 //     	['zelda hidden chests','link', 'loream ispam',  50]

 //      ];
 //      print_r($blogs);
 //      echo "<br>";
 //      print_r($blogs[0][3]);
 //      echo "<br>";
 //      print_r($blogs[1]);
 //      echo "<br>";





 //      $blogs =[
 //      	['title' =>'mario party' ,'author' =>'mario', 'content' => 'loren',  'likes' => 30],
 //      	['title' =>'mario kart cheats' ,'author' =>'toad','content' => 'lorem', 'likes' => 25],
 //     	['title' =>'zelda hidden chests','author' =>'link','content' => 'loream ispam', 'likes' => 50]

 //      ];
 //      print_r($blogs);
 //      echo "<br>";
 //      print_r($blogs[0]);
 //      echo "<br>";
 //      print_r($blogs[2]);
 //      echo "<br>";
 //      echo $blogs[2]['author'];
 //      echo "<br>";
 //      echo "<br>";


 //      echo count($blogs);     //output = 3
 //      echo "<br>";



 //      //from multidimensional array pop

 //      $blogs[] =['title' =>'castle party','auuthor'=>'peach', 'content' =>'lorem', 'likes' =>100];
 //      $popped = array_pop($blogs);
 //      print_r($popped);
 //      echo "<br>";





 //      ///loops///

 //      //using for loop

 //      $ninjas =['shaun','ryn', 'youshi'];
 //      for($i = 0; $i < count($ninjas); $i++){
 //      	echo $ninjas[$i] . '<br />';
 //      }

 //      echo "<br>";

 //      //using foreach
 //      $ninjas = ['crystal', 'water', 'drop'];
 //      foreach($ninjas as $ninja){
 //      	echo $ninja . '<br />';
 //      }
 //      echo "<br>";



 //      $products = [
 //      	['name' => 'shiny star', 'price' => 20],
 //      	['name' => 'green shell', 'price' => 10],
 //      	['name' => 'red shell', 'price' => 15],
 //      	['name' => 'gold coin' , 'price' => 5],
 //      	['name' => 'lightning blot', 'price' =>4]
 //      ];

 //      foreach($products as $product){
 //      	echo $product['name'] . ' - ' . $product['price'];
 //      	echo '<br />';
 //      }

 //      echo "<br>";


 //      //using while loop

 //       $products = [
 //      	['name' => 'shiny star', 'price' => 20],
 //      	['name' => 'green shell', 'price' => 10],
 //      	['name' => 'red shell', 'price' => 15],
 //      	['name' => 'gold coin' , 'price' => 55],
 //      	['name' => 'lightning blot', 'price' =>40]
 //      ];

 //      $i = 0;
 //      while($i < count($products)){
 //      	echo($products[$i]['name'] . ' - ' . $products[$i]['price']);
 //      	echo '<br />';
 //      	$i++;
 //      }

 //      echo "<br>";






 //      ///booleans & comparisons

 //      echo true;    //1
 //      echo false;     //empty string

 //      echo "<br>";

 //      //numbers
 //      echo 5<10;     //true
 //      echo 5>10 ;    //false
 //      echo 5==10;    //false
 //      echo "<br>";
 //      echo 5!=10;    //true
 //      echo "<br>";
 //      echo 5<=5;     ///true
 //      echo "<br>";
 //      echo 5>=5;     //true;
 //      echo "<br>";

 //      //strings

 //      echo 'shaun'<'youshi';      //true (s coome before y so s small than y)
 //      echo "<br>";
 //      echo 'shaun'>'youshi';     //false
 //      echo "<br>";

 //      echo 'shaun' > 'Shaun';     //true small s letter is greater then capital s letter
 //      echo "<br>";
 //      echo 'mario' =='mario';   //true
 //      echo "<br>";

 //      echo 'mario' == 'Mario';   //false

 //      echo "<br>";



 //      //loose vs strict equal comparison
 //      echo 5 == '5';      //true
 //      echo "<br>";

 //      echo 5 === '5';     //false (strickly compariosn)
 //    //  echo "<br>";
 //      echo 5 === 5;  //true


 //      echo "<br>";


 //      echo true == "1";    //true
 //      echo "<br>";

 //      echo false == "";     //true
 //      echo "<br>";






 //      ///conditional statements///

 //      //if statement
 //      $price = 20;
 //      echo $price;
 //      echo "<br>";
 //      if($price < 10){
 //      	echo 'the condition is met';
 //      }

 //      else if($price < 20){
 //      	echo ' else if condition met';
 //      }
 //      else{
 //      	echo 'condition not met';
 //      }

 //      echo "<br>";


 //      $products=[['name' => 'cabbage' , 'price' =>20],
 //      ['name' => 'banana' ,'price' => 10],
 //      ['name' =>'Cauliflower', 'price' =>15],
 //      ['name' =>'beans' , 'price' =>5],
 //      ['name' =>'peas', 'price' =>40],
 //      ['name' =>'papaya' , 'price' =>2]];

 //      foreach($products as $product){
 //      	if($product['price'] < 15){
 //      		echo $product['name'] . '-'. $product['price'] .'<br />';
 //      	}
 //      }

 //      echo "<br>";


 //      foreach($products as $product){
 //      	if($product['price'] <15 && $product['price']> 2){
 //      		echo $product['name'] .'-'. $product['price'] .'<br />';
 //      	}
 //      }

 //      echo "<br>";

 //      foreach($products as $product){
 //      	if($product['price'] >20 || $product['price']< 10){
 //      		echo $product['name'] .'-'. $product['price'] .'<br />';
 //      	}
 //      }


 //      echo "<br>";





 //      ///continue and Break///

 //      //continue

 //      $products =[
 //      	['name' => 'shiny star', 'price' => 20],
 //      	['name' => 'green shell', 'price' => 10],
 //      	['name' => 'red shell', 'price' => 15],
 //      	['name' => 'gold coin', 'price' => 5],
 //      	['name' => 'lightning bolt', 'price' => 40],
 //      	['name' => 'banana skin', 'price' => 2]
 //      ];

 //      foreach($products as $product){
 //      	if($product['name'] == 'lightning bolt'){
 //      		break;
 //      	}
	  
 //      echo $product['name'] . "<br />";
 //  }


 //  		echo "<br>";

 //  		$products =[
 //      	['name' => 'shiny star', 'price' => 20],
 //      	['name' => 'green shell', 'price' => 10],
 //      	['name' => 'red shell', 'price' => 15],
 //      	['name' => 'gold coin', 'price' => 5],
 //      	['name' => 'lightning bolt', 'price' => 40],
 //      	['name' => 'banana skin', 'price' => 2]
 //      ];


 //  		foreach($products as $product){
 //      	if($product['name'] == 'lightning bolt'){
 //      		break;
 //      	}

 //      	if($product['price'] > 15){
 //      		continue;
 //      	}
	  
 //      echo $product['name'] . "<br />";
 //  }

 //  		echo "<br>";




 //  		///function///

 //  		function hello(){
 //  			echo "good morning";
 //  		}
 //  		hello();     

 //  		echo "<br>";

 //  		function sayhello($name){
 //  			echo "good morning $name";
 //  		}
 //  		sayhello('mario');

 //  		echo "<br>";

 //  		function world($name = "shaun"){
 //  			echo "good morning $name";
 //  		}
 //  		world();


 //  		echo "<br>";


 //  		function worldly($name = "shaun", $time = 'night'){
 //  			echo "good $time $name";
 //  		}
 //  		worldly();

 //  		echo "<br>";

 //  		function earth($name = "shaun"){
 //  			echo "good morning $name";
 //  		}
 //  		earth("de mariya");

 //  		echo "<br>";



 //  		function formatproduct($product){
 //  			echo "{$product['name']} costs £{$product['price']} to buy <br />";
 //  		}
 //  		formatproduct(['name' => 'gold star','price' => 20]);

 //  		echo "<br>";


 //  		function formatproduction($product){
 //  			return "{$product['name']} costs £{$product['price']} to buy <br />";
 //  		}
 //  		$formatted = formatproduction(['name' => 'gold star','price' => 20]);

 //  		echo $formatted;

 //  		echo "<br>";




 //  		///variable scope///

 //  		//local variable

 //  		function myfunc(){
 //  			$price = 10;
 //  			echo $price;
 //  		}
 //  		myfunc();

 //  		echo "<br>";

 //  		//using global variable

 //  		$name = 'mario';
 //  		function queen(){
 //  			global $name;
 //  			echo $name;
 //  		}
 //  		queen();


 //  		echo "<br>";


 //  		$name = 'mario';
 //  		function king(){
 //  			global $name;
 //  			$name = 'yoshi';
 //  			echo $name;
 //  		}
 //  		king();
 //  		echo $name;    //yoshi  (because of inside function using global variable)

 //  		echo "<br>";




 //  		$name = 'mario';
 //  		function poet($name){
			
 //  			echo "bye $name";
 //  		}
 //  		poet($name);


 //  		echo "<br>";

 //  		$name = 'mario';
 //  		function poetry($name){
 //  			$name = 'wario';
 //  			echo "bye $name";
 //  		}
 //  		poetry($name);
 //  		echo $name;


 //  		echo "<br>";

 //  		$name = 'mario';
 //  		function pot(&$name){   //using address
 //  			$name = 'wario';
 //  			echo "bye $name";
 //  		}
 //  		pot($name);     //reference
 //  		echo ($name);



 //  		echo "<br>";








 //  		///include & require

 //  		include('ninjas.php');
 //  		require('ninjas.php');
 //  		echo 'end of php';

 //  		echo "<br>";

 //  		require('ninjas.php');
 //  		include('ninjas.php');
 //  		echo "end";

 //  		echo "<br>";










	










	///connect to database///

		//MYSQL or PDO(PHP data objects)//

  // 		$conn = mysqli_connect('localhost', 'shaun', 'test1234', 'ninja_pizza');

  // 		//check connection//

  // 		if(!$conn){
  // 			echo 'connection error: ' . mysqli_connect_error();
  // 		}

  // 		//write query for all pizzas//
		// $sql = 'SELECT title, ingredients, id FROM pizzas';

  // 		//make query & get result//
		// $result = mysqli_query($conn, $sql);

  // 		//fetch the resulting rows as an array//
  // 		$pizzas = mysqli_fetch_all($result, MYSQLI_ASSOC);

  // 		//free result from memory//   ***(good practice)***
  // 		mysqli_free_result($result);

  // 		//close connection//
  // 		mysqli_close($conn);

  // 		print_r($pizzas);


  // 		echo "<br>";




		///rendering data to the browser///

		//using chronological order//
		// $conn = mysqli_connect('localhost', 'shaun', 'test1234', 'ninja_pizza');

		// //check connection//

		// if(!$conn){
		// 	echo 'connection error: ' . mysqli_connect_error();
		// }

		// //write query for all pizzas//
		// $sql = 'SELECT title, ingredients, id FROM pizzas ORDER BY created_at';

		// //make query & get result//
		// $result = mysqli_query($conn, $sql);

		// //fetch the resulting rows as an array//
		// $pizzas = mysqli_fetch_all($result, MYSQLI_ASSOC);

		// //free result from memory//   ***(good practice)***
		// mysqli_free_result($result);

		// //close connection//
		// mysqli_close($conn);

		//print_r($pizzas);



		//print_r(explode(',',$pizzas[0]['ingredients']));










 			include('config/db_connect.php');

		//write query for all pizzas//
		$sql = 'SELECT title, ingredients, id FROM pizzas ORDER BY created_at';

		//make query & get result//
		$result = mysqli_query($conn, $sql);

		//fetch the resulting rows as an array//
		$pizzas = mysqli_fetch_all($result, MYSQLI_ASSOC);

		//free result from memory//   ***(good practice)***
		mysqli_free_result($result);

		//close connection//
		mysqli_close($conn);
















?> 


<!DOCTYPE html>
<html>


	<?php include('templates/header.php');?>


	<h4 class="center grey-text">Pizzas!</h4>

	<div class="container">
		<div class="row">

			<?php foreach($pizzas as $pizza){ ?>

				<div class="col s6 md3">
					<div class="card z-depth-0">
						<img src="img/pizza.jpg" class="pizza">
					<div class="card-content center">
						<h6><?php echo htmlspecialchars($pizza['title']); ?></h6>
						<ul>
							<?php foreach(explode(',',$pizza['ingredients']) as $ing){ ?>
								<li><?php echo htmlspecialchars($ing) ?></li>
						 	<?php } ?> 
						</ul>
					</div>
					<div class="card-action right-align">
						<a class="brand-text" href="details.php?id=<?php echo $pizza['id']?>">more info</a>
					 </div>
				</div>
			</div>

			<?php
			}  ?>        

									<!-- control flow alt syntax(using colon sign instead of curley bracate in html) -->

			<?php if(count($pizzas) >= 2): ?>
				<p>There are 2 or more pizzas</p>
			<?php  else: ?>
				<p>There are less than 2 pizzas</p>
			<?php endif; ?>

		</div>
		</div>


	<?php include('templates/footer.php');?>


<!-- <head>
	<title> PHP tutorials </title>
</head>
<body>
	<?php include('content.php'); ?>
	<?php include('content.php'); ?>
	<?php include('content.php'); ?> -->





</body>
</html>








