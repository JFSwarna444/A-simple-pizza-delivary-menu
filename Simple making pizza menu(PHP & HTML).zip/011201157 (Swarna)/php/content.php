<div>
	<h1><?php echo 'some content !!!!' ?></h1>
</div>